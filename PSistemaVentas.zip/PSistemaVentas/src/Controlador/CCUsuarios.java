package Controlador;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;
import Modelo.CMUsuarios;

public class CCUsuarios {
    PreparedStatement ps;
    ResultSet rs;
    Conexion cone=new Conexion();
    Connection conecta;
    
    public CMUsuarios ValidarUsuario(String user, String pass)
    {
        CMUsuarios cmu=new CMUsuarios();
        String ConSQL="SELECT * FROM USUARIOS " +
                      "WHERE user_usuario=? AND " +
                      "pass_usuario=?";
        
        try {
            conecta=cone.conectar();
            ps=conecta.prepareStatement(ConSQL);
            ps.setString(1, user);
            ps.setString(2, pass);
            rs=ps.executeQuery();
            
            while(rs.next())
            {
              cmu.setIdusuario(rs.getInt("id_usuario"));
              cmu.setUserusuario(rs.getString("user_usuario"));
              cmu.setPassusuario("pass_usuario");
            }
            
            
        } catch (Exception e) {
            //vacio
        }
        
        return cmu;
    }        
    
}
