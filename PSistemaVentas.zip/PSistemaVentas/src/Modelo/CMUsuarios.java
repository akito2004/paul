
package Modelo;

public class CMUsuarios {
    int idusuario,rolusuario;
    String dniusuario,nomusuario,apeusuario,userusuario,passusuario,fotousuario;
    
    public CMUsuarios()
    {
        idusuario=0;
        rolusuario=0;
        dniusuario=null;
        nomusuario=null;
        apeusuario=null;
        userusuario=null;
        passusuario=null;
        fotousuario=null;
    }

    public CMUsuarios(int idusuario, int rolusuario, String dniusuario, String nomusuario, String apeusuario, String userusuario, String passusuario, String fotousuario) {
        this.idusuario = idusuario;
        this.rolusuario = rolusuario;
        this.dniusuario = dniusuario;
        this.nomusuario = nomusuario;
        this.apeusuario = apeusuario;
        this.userusuario = userusuario;
        this.passusuario = passusuario;
        this.fotousuario = fotousuario;
    }

    public int getIdusuario() {
        return idusuario;
    }

    public void setIdusuario(int idusuario) {
        this.idusuario = idusuario;
    }

    public int getRolusuario() {
        return rolusuario;
    }

    public void setRolusuario(int rolusuario) {
        this.rolusuario = rolusuario;
    }

    public String getDniusuario() {
        return dniusuario;
    }

    public void setDniusuario(String dniusuario) {
        this.dniusuario = dniusuario;
    }

    public String getNomusuario() {
        return nomusuario;
    }

    public void setNomusuario(String nomusuario) {
        this.nomusuario = nomusuario;
    }

    public String getApeusuario() {
        return apeusuario;
    }

    public void setApeusuario(String apeusuario) {
        this.apeusuario = apeusuario;
    }

    public String getUserusuario() {
        return userusuario;
    }

    public void setUserusuario(String userusuario) {
        this.userusuario = userusuario;
    }

    public String getPassusuario() {
        return passusuario;
    }

    public void setPassusuario(String passusuario) {
        this.passusuario = passusuario;
    }

    public String getFotousuario() {
        return fotousuario;
    }

    public void setFotousuario(String fotousuario) {
        this.fotousuario = fotousuario;
    }    
}
